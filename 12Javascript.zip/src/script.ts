import PromptSync = require("prompt-sync");

const prompt = PromptSync();

let peso = 0
let altura = 0

let imc = (peso,altura) => {
return (peso / Math.pow(altura, 2));
}
peso=Number(prompt('Informe o seu peso porfavor:'))
altura =Number(prompt('Informe o seu peso por favor:'))

console.log('Costatamos que seu indice corporal é de exatamente:')

${imc(peso,altura)}
