// exercício da folha 
JavaScript - 12
