import PromptSync =require('prompt-sync');

const prompt = PromptSync();
const Imc = (peso: number,altura: number) => {
return peso / Math.pow(altura, 2);
}

const peso=Number(prompt('Me informe seu peso:'));
const altura=Number(prompt('Me informe seu altura:'));

const imc = Imc(peso,altura);

console.log(`Valor do IMC: ${imc.toFixed(0)}`);
